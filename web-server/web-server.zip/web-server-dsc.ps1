﻿configuration Create 
{ 

    #Import-DscResource -ModuleName xActiveDirectory, xDisk, xNetworking, xPendingReboot, cDisk
    #[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    # Custom Resources
    Import-DscResource -ModuleName cSmbShare
    Import-DscResource -ModuleName cScheduledTask
    Import-DscResource -ModuleName cWebAdministration
    Import-DscResource -ModuleName cWebGlobalConfig

    # MS Resources
    Import-DscResource -ModuleName xPSDesiredStateConfiguration
    Import-DscResource -ModuleName xPowerShellExecutionPolicy
    Import-DscResource -ModuleName xCredSSP
    Import-DscResource -ModuleName xWebAdministration

    $Drive = "C:\"
    $LogsPath = ($Drive + "Logs")
    $ScriptsPath = ($Drive + "Scripts")
    $UtilsPath = ($Drive + "Utils")

    $WebPath = ($Drive + "Web")
    $IisPath = ($Drive + "IIS")

    Node localhost
    {
        LocalConfigurationManager
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        } 

        foreach($Feature in @(
                "Web-Server","Application-Server","AS-WAS-Support","AS-HTTP-Activation",
                "AS-TCP-Activation","AS-Named-Pipes","Web-Http-Redirect","Web-ASP",
                "Web-Log-Libraries","Web-Request-Monitor","Web-Http-Tracing","Web-Custom-Logging",
                "Web-Basic-Auth","Web-Windows-Auth","Web-Digest-Auth","Web-Dyn-Compression",
                "Web-Mgmt-Tools","Web-Scripting-Tools","Web-Mgmt-Service","Web-Mgmt-Compat",
                "Web-WMI","Web-Lgcy-Scripting","RDC")
                )
        {
            WindowsFeature $Feature
            {
                Ensure = "Present"
                Name = "$Feature"
            }
        }

        # Global IIS Settings
            
            cWebGlobalConfig TraceFailedReqLogDirectory { Setting = "TraceFailedReqLogDirectory"; Value = "$LogsPath\logs\FailedReqLogFiles" }
            cWebGlobalConfig LogFileDirectory { Setting = "LogFileDirectory"; Value = "$LogsPath" }
            cWebGlobalConfig BinaryLogFileDirectory { Setting = "BinaryLogFileDirectory"; Value = "$LogsPath" }
            cWebGlobalConfig W3CLogFileDirectory { Setting = "W3CLogFileDirectory"; Value = "$LogsPath" }
            cWebGlobalConfig LogExtFileFlags { Setting = "LogExtFileFlags"; Value = "Date,Time,ClientIP,UserName,ServerIP,Method,UriStem,UriQuery,HttpStatus,BytesSent,BytesRecv,TimeTaken" }
            cWebGlobalConfig ConfigHistoryPath { Setting = "ConfigHistoryPath"; Value = "$IisPath\history"}
            cWebGlobalConfig AspDiskTemplateCacheDirectory { Setting = "AspDiskTemplateCacheDirectory"; Value = "$IisPath\temp\ASP Compiled Templates"}
            cWebGlobalConfig IisCompressedFilesDirectory { Setting = "IisCompressedFilesDirectory"; Value = "$IisPath\temp\IIS Temporary Compressed Files"}
            cWebGlobalConfig LocalTimeRollover { Setting = "LocalTimeRollover"; Value = "True"}

            File InetpubCopy
            {
                Ensure = "Present"
                DestinationPath = "$IisPath"
                SourcePath = "C:\inetpub"
                MatchSource = "False"
                Type = "Directory"
                DependsOn = "[WindowsFeature]Web-Server"
            }

            File WwwrootRemoval
            {
                Ensure = "Absent";
                DestinationPath = "$IisPath\wwwroot";
                Type = "Directory"
                DependsOn = "[File]InetpubCopy"
            }
                        
            Registry WwwRootPath
            {
                Ensure = "Present"
                Key = "HKEY_LOCAL_MACHINE\Software\Microsoft\inetstp"
                ValueName = "PathWWWRoot"
                ValueData = "$WebPath"
                ValueType = "String"
            }
            
            Registry WasParameters
            {
                Ensure = "Present"
                Key = "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\WAS\Parameters"
                ValueName = "ConfigIsolationPath"
                ValueData = "$IisPath\temp\appPools"
                ValueType = "String"
            }

            Registry WebManagement
            {
                Ensure = "Present"
                Key = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WebManagement\Server"
                ValueName = "EnableRemoteManagement"
                ValueData = "1"
            }
            
            # WebSites
            <#
            foreach($Site in @(
                "TestWebSite1","TestWebSite2"
                )
            )
            
            {
                File $Site
                {
                    SourcePath = "\\NAS\Code\$Site\Production" # Update this source path to whatever is relevant for your environment.
                    DestinationPath = "$WebPath\$Site"
                    Credential = $Credential
                    Checksum = "SHA-1"
                    Ensure = "Present"
                    Force = "True"
                    Recurse = "True"
                    Type = "Directory"
                    MatchSource = "True"
                    DependsOn = "[WindowsFeature]Web-Server"
                }
                
                cWebAppPool $Site
                {
                    Name = "AppPool - $Site"
                    Ensure = "Present"
                    State = "Started"
                    IdentityCredential = $Credential
                    DependsOn = "[File]$Site"
                }
                
                cWebSite $Site
                {
                    Name = "$Site"
                    Ensure = "Present"
                    PhysicalPath = "$WebPath\$Site"
                    State = "Started"
                    ApplicationPool = "AppPool - $Site"
                    BindingInfo = cWebBindingInformation
                        {
                            Port = "80";
                            Protocol = "http";
                            HostName = "$Site.domain.com"; # Update the domain!
                        }
                    DependsOn = "[cWebAppPool]$Site"
                }
            }            
            #>
            # Remove Default Site
            
            cWebSite DefaultWebSite
            {
                Name = "Default Web Site"
                Ensure = "Absent"
            }

   }
}